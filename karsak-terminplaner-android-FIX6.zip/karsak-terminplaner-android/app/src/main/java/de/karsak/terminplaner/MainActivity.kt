package de.karsak.terminplaner

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingNativeListen = false

    private var textToSpeech: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var pendingSpeech: SpeechRequest? = null
    private var speechRecognizer: SpeechRecognizer? = null

    data class SpeechRequest(
        val message: String,
        val volumePercent: Int,
        val gender: String,
        val listenAfter: Boolean
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val audioGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (pendingWebPermission != null) {
            if (audioGranted) pendingWebPermission?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            else pendingWebPermission?.deny()
            pendingWebPermission = null
        }
        if (pendingNativeListen) {
            pendingNativeListen = false
            if (audioGranted) startNativeListening()
            else sendSpeechResult(null, "Mikrofonzugriff wurde nicht erlaubt.")
        }

        val locationGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (pendingGeoCallback != null) {
            pendingGeoCallback?.invoke(pendingGeoOrigin, locationGranted, false)
            pendingGeoOrigin = null
            pendingGeoCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val tts = textToSpeech ?: return@TextToSpeech
                val result = tts.setLanguage(Locale.GERMANY)
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                tts.setSpeechRate(0.92f)
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId?.startsWith("listen-") == true) runOnUiThread { startNativeListening() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (utteranceId?.startsWith("listen-") == true) runOnUiThread { startNativeListening() }
                    }
                })
                pendingSpeech?.let {
                    pendingSpeech = null
                    speakNative(it.message, it.volumePercent, it.gender, it.listenAfter)
                }
            } else {
                ttsReady = false
                Toast.makeText(this, "Android-Sprachausgabe konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.setGeolocationEnabled(true)
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.userAgentString = webView.settings.userAgentString + " KarsakTerminplanerAndroid/1.0.6"

        val bridge = AndroidBridge(this)
        webView.addJavascriptInterface(bridge, "Android")
        webView.addJavascriptInterface(bridge, "KarsakAndroid")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.scheme == "file") false else {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        } else {
                            pendingWebPermission = request
                            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                        }
                    } else request.deny()
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (fine || coarse) callback?.invoke(origin, true, false)
                else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
            }
        }

        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun speakNative(message: String, volumePercent: Int, gender: String, listenAfter: Boolean = false) {
        val safeMessage = message.trim()
        if (safeMessage.isEmpty()) {
            if (listenAfter) startNativeListening()
            return
        }
        if (!ttsReady) {
            pendingSpeech = SpeechRequest(safeMessage, volumePercent, gender, listenAfter)
            return
        }
        val tts = textToSpeech ?: return
        val volume = (volumePercent.coerceIn(0, 100) / 100f).coerceAtLeast(0.01f)
        tts.setPitch(if (gender.equals("male", true)) 0.90f else 1.08f)
        tts.setSpeechRate(0.92f)
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume) }
        val prefix = if (listenAfter) "listen" else "speak"
        val utteranceId = "$prefix-${System.currentTimeMillis()}"
        tts.stop()
        tts.speak(safeMessage, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    private fun startNativeListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingNativeListen = true
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendSpeechResult(null, "Spracherkennung ist auf diesem Gerät nicht verfügbar.")
            return
        }
        speechRecognizer?.destroy()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onError(error: Int) {
                sendSpeechResult(null, when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Sprache nicht verstanden. Bitte erneut versuchen."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Keine Sprache erkannt. Bitte erneut versuchen."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofonzugriff wurde nicht erlaubt."
                    else -> "Spracherkennung konnte nicht gestartet werden. Bitte erneut versuchen."
                })
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                sendSpeechResult(text, if (text.isNullOrBlank()) "Sprache nicht verstanden. Bitte erneut versuchen." else null)
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer.startListening(intent)
    }

    private fun sendSpeechResult(text: String?, error: String?) {
        runOnUiThread {
            val js = "window.karsakNativeSpeechResult && window.karsakNativeSpeechResult(" +
                    (text?.let { JSONObject.quote(it) } ?: "null") + "," +
                    (error?.let { JSONObject.quote(it) } ?: "null") + ");"
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onDestroy() {
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    inner class AndroidBridge(private val context: Context) {
        @android.webkit.JavascriptInterface
        fun scheduleReminder(id: Int, epochMillis: Long, title: String, message: String) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("title", title); putExtra("message", message); putExtra("id", id)
            }
            val pendingIntent = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
            } catch (_: SecurityException) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                Toast.makeText(context, "Exakte Alarme bitte in Android erlauben.", Toast.LENGTH_LONG).show()
                if (android.os.Build.VERSION.SDK_INT >= 31) runCatching {
                    context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun cancelReminder(id: Int) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingIntent = PendingIntent.getBroadcast(context, id, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarmManager.cancel(pendingIntent)
        }

        @android.webkit.JavascriptInterface
        fun speak(message: String, volumePercent: Int, gender: String) = runOnUiThread {
            speakNative(message, volumePercent, gender, false)
        }

        @android.webkit.JavascriptInterface
        fun speakThenListen(message: String, volumePercent: Int, gender: String) = runOnUiThread {
            speakNative(message, volumePercent, gender, true)
        }

        @android.webkit.JavascriptInterface
        fun startListening() = runOnUiThread { startNativeListening() }

        @android.webkit.JavascriptInterface
        fun isNativeApp(): Boolean = true
    }
}
