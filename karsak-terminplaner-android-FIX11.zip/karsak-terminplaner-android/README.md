# Karsak Terminplaner – Android

Dieses Projekt verpackt den Karsak Terminplaner als Android-App.

## Ohne Laptop bauen
1. Neues GitHub-Repository erstellen, z. B. `karsak-terminplaner-android`.
2. Alle Dateien dieses ZIPs in das Repository hochladen.
3. Oben im Repository auf **Actions** tippen.
4. Workflow **Android APK bauen** öffnen.
5. Falls nötig **Run workflow** wählen.
6. Nach erfolgreichem Lauf unter **Artifacts** `Karsak-Terminplaner-APK` herunterladen.
7. ZIP öffnen und `app-debug.apk` auf dem Android-Handy installieren.

## Was diese erste Android-Version schon kann
- Öffnet die bestehende Terminplaner-Web-App ohne eigene Browser-Bedienung.
- Mikrofon-Berechtigung für die Spracheingabe.
- Standort-Berechtigung vorbereitet.
- Native Android-Schnittstelle für Termin-Erinnerungen und Alarmmeldungen.
- Externe Links wie Google Maps werden außerhalb der App geöffnet.

## Nächster Schritt
Die Web-App muss beim Speichern/Ändern/Löschen von Terminen die Android-Schnittstelle `KarsakAndroid.scheduleReminder(...)` bzw. `KarsakAndroid.cancelReminder(...)` aufrufen. Dann funktionieren echte Android-Alarme auch bei geschlossenem Terminplaner.


## FIX4
Native Android-TextToSpeech-Anbindung ergänzt. Die Web-App kann jetzt über `window.Android.speak(...)` die Android-Sprachausgabe verwenden.


## FIX5
Die App enthält die Terminplaner-Oberfläche lokal und verwendet Android TextToSpeech sowie Android SpeechRecognizer direkt. Dadurch sind Stimme und Mikrofon nicht mehr von der GitHub-Pages-/WebView-Sprachunterstützung abhängig.

## FIX9
- Sprachdialog läuft automatisch weiter: Nach jeder Frage startet das Mikrofon erneut.
- Adressschritt unterbricht den Sprachdialog nicht mehr durch eine manuelle Bestätigung.
- Kürzere, flüssigere Fragen und modernere TTS-Auswahl/Sprechgeschwindigkeit.
- Name in der Begrüßung auf „Herr Karsak“ korrigiert.
- Uhrzeiten wie „18 Uhr 30“ werden als 18:30 verarbeitet.
- Alarm-Auswahl erweitert: 60, 45, 30, 20, 15, 10, 5 Minuten sowie Terminzeit.
- Fahrzeit verwendet Android-Standort + Geocoding-Schätzung statt fester/simulierter 30–50 Minuten.
- Bei fehlendem Standort wird keine erfundene Fahrzeit angezeigt; Google Maps bleibt für Live-Verkehr/Route zuständig.
