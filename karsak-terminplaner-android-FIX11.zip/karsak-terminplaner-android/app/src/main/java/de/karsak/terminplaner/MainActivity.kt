package de.karsak.terminplaner

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingNativeListen = false

    private var textToSpeech: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var pendingSpeech: SpeechRequest? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var listenFallback: Runnable? = null
    private var startListenRunnable: Runnable? = null
    @Volatile private var nativeListening = false
    private var nativeListenRetries = 0

    data class SpeechRequest(
        val message: String,
        val volumePercent: Int,
        val gender: String,
        val listenAfter: Boolean
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val audioGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (pendingWebPermission != null) {
            if (audioGranted) pendingWebPermission?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
            else pendingWebPermission?.deny()
            pendingWebPermission = null
        }
        if (pendingNativeListen) {
            pendingNativeListen = false
            if (audioGranted) requestNativeListening(250L, resetRetries = true)
            else sendSpeechResult(null, "Mikrofonzugriff wurde nicht erlaubt.")
        }

        val locationGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (pendingGeoCallback != null) {
            pendingGeoCallback?.invoke(pendingGeoOrigin, locationGranted, false)
            pendingGeoOrigin = null
            pendingGeoCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        }

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val tts = textToSpeech ?: return@TextToSpeech
                val result = tts.setLanguage(Locale.GERMANY)
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                tts.setSpeechRate(1.03f)
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        if (utteranceId?.startsWith("listen-") == true) runOnUiThread {
                            listenFallback?.let(mainHandler::removeCallbacks)
                            listenFallback = null
                            requestNativeListening(420L, resetRetries = true)
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (utteranceId?.startsWith("listen-") == true) runOnUiThread {
                            listenFallback?.let(mainHandler::removeCallbacks)
                            listenFallback = null
                            requestNativeListening(500L, resetRetries = true)
                        }
                    }
                })
                pendingSpeech?.let {
                    pendingSpeech = null
                    speakNative(it.message, it.volumePercent, it.gender, it.listenAfter)
                }
            } else {
                ttsReady = false
                Toast.makeText(this, "Android-Sprachausgabe konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.setGeolocationEnabled(true)
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.userAgentString = webView.settings.userAgentString + " KarsakTerminplanerAndroid/1.0.10"

        val bridge = AndroidBridge(this)
        webView.addJavascriptInterface(bridge, "Android")
        webView.addJavascriptInterface(bridge, "KarsakAndroid")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.scheme == "file") false else {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        } else {
                            pendingWebPermission = request
                            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                        }
                    } else request.deny()
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (fine || coarse) callback?.invoke(origin, true, false)
                else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
            }
        }

        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun speakNative(message: String, volumePercent: Int, gender: String, listenAfter: Boolean = false) {
        val safeMessage = message.trim()
        if (safeMessage.isEmpty()) {
            if (listenAfter) requestNativeListening(250L, resetRetries = true)
            return
        }
        if (!ttsReady) {
            pendingSpeech = SpeechRequest(safeMessage, volumePercent, gender, listenAfter)
            return
        }
        val tts = textToSpeech ?: return
        val volume = (volumePercent.coerceIn(0, 100) / 100f).coerceAtLeast(0.01f)
        val germanVoices = tts.voices?.filter { it.locale?.language == Locale.GERMAN.language }.orEmpty()
        val genderHints = if (gender.equals("male", true)) {
            listOf("male", "mann", "hans", "markus", "stefan", "conrad", "bernd", "klaus", "daniel")
        } else {
            listOf("female", "frau", "anna", "katja", "petra", "amelie", "vicki", "sandy", "helena", "marlene", "hedda")
        }
        val bestVoice = germanVoices
            .sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
            .firstOrNull { v -> genderHints.any { h -> v.name.lowercase(Locale.GERMANY).contains(h) } }
            ?: germanVoices.sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired }).firstOrNull()
        if (bestVoice != null) tts.voice = bestVoice
        tts.setPitch(if (gender.equals("male", true)) 0.97f else 1.02f)
        tts.setSpeechRate(1.03f)
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume) }
        val prefix = if (listenAfter) "listen" else "speak"
        val utteranceId = "$prefix-${System.currentTimeMillis()}"
        listenFallback?.let(mainHandler::removeCallbacks)
        listenFallback = null
        tts.stop()
        tts.speak(safeMessage, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (listenAfter) {
            val estimatedMs = (safeMessage.length * 70L).coerceIn(1500L, 5200L)
            listenFallback = Runnable {
                listenFallback = null
                if (!tts.isSpeaking) requestNativeListening(200L, resetRetries = true) else requestNativeListening(900L, resetRetries = true)
            }.also { mainHandler.postDelayed(it, estimatedMs + 700L) }
        }
    }

    private fun requestNativeListening(delayMs: Long = 0L, resetRetries: Boolean = false) {
        if (resetRetries) nativeListenRetries = 0
        startListenRunnable?.let(mainHandler::removeCallbacks)
        startListenRunnable = Runnable {
            startListenRunnable = null
            startNativeListening()
        }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun disposeSpeechRecognizer() {
        val old = speechRecognizer
        speechRecognizer = null
        nativeListening = false
        runCatching { old?.cancel() }
        runCatching { old?.destroy() }
    }

    private fun retryNativeListening(message: String? = null) {
        if (nativeListenRetries < 4) {
            nativeListenRetries++
            message?.let { sendAssistantStatus(it) }
            disposeSpeechRecognizer()
            requestNativeListening(420L + nativeListenRetries * 120L)
        } else {
            nativeListenRetries = 0
            disposeSpeechRecognizer()
            sendSpeechResult(null, message ?: "Spracherkennung konnte nicht gestartet werden. Ich versuche es erneut.")
        }
    }

    private fun sendAssistantStatus(message: String) {
        runOnUiThread {
            val js = "window.karsakNativeSpeechStatus && window.karsakNativeSpeechStatus(" + JSONObject.quote(message) + ");"
            webView.evaluateJavascript(js, null)
        }
    }

    private fun startNativeListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingNativeListen = true
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendSpeechResult(null, "Spracherkennung ist auf diesem Gerät nicht verfügbar.")
            return
        }

        // Nie in die eigene Sprachausgabe hinein zuhören. Nach dem letzten Wort kurz warten.
        if (textToSpeech?.isSpeaking == true) {
            requestNativeListening(300L)
            return
        }
        if (nativeListening) return

        disposeSpeechRecognizer()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = recognizer
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (speechRecognizer !== recognizer) return
                nativeListening = true
                nativeListenRetries = 0
                sendAssistantStatus("Jetzt sprechen …")
            }
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onError(error: Int) {
                if (speechRecognizer !== recognizer) return
                nativeListening = false
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        disposeSpeechRecognizer()
                        sendSpeechResult(null, "Mikrofonzugriff wurde nicht erlaubt.")
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_CLIENT -> retryNativeListening("Mikrofon wird neu gestartet …")
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retryNativeListening("Ich habe nichts verstanden. Ich höre noch einmal zu …")
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                    SpeechRecognizer.ERROR_SERVER -> retryNativeListening("Spracherkennung wird erneut gestartet …")
                    else -> retryNativeListening("Mikrofon wird erneut gestartet …")
                }
            }
            override fun onResults(results: Bundle?) {
                if (speechRecognizer !== recognizer) return
                nativeListening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                disposeSpeechRecognizer()
                nativeListenRetries = 0
                if (text.isNullOrBlank()) {
                    requestNativeListening(450L, resetRetries = true)
                } else {
                    sendSpeechResult(text, null)
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        }
        nativeListening = true
        try {
            recognizer.startListening(intent)
        } catch (_: Throwable) {
            nativeListening = false
            retryNativeListening("Mikrofon wird neu gestartet …")
        }
    }

    private fun sendSpeechResult(text: String?, error: String?) {
        runOnUiThread {
            val js = "window.karsakNativeSpeechResult && window.karsakNativeSpeechResult(" +
                    (text?.let { JSONObject.quote(it) } ?: "null") + "," +
                    (error?.let { JSONObject.quote(it) } ?: "null") + ");"
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onDestroy() {
        listenFallback?.let(mainHandler::removeCallbacks)
        listenFallback = null
        startListenRunnable?.let(mainHandler::removeCallbacks)
        startListenRunnable = null
        disposeSpeechRecognizer()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    private fun bestLastKnownLocation(): Location? {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return runCatching {
            manager.getProviders(true).mapNotNull { provider -> runCatching { manager.getLastKnownLocation(provider) }.getOrNull() }
                .maxByOrNull { it.time }
        }.getOrNull()
    }

    private fun estimateDriveMinutesForAddress(address: String): Int {
        val origin = bestLastKnownLocation() ?: return -1
        if (address.isBlank()) return -1
        val geocoder = Geocoder(this, Locale.GERMANY)
        val query = if (address.contains(',')) address else {
            val locality = runCatching { geocoder.getFromLocation(origin.latitude, origin.longitude, 1)?.firstOrNull()?.locality }.getOrNull()
            if (!locality.isNullOrBlank()) "$address, $locality" else address
        }
        val destination = runCatching { geocoder.getFromLocationName(query, 1)?.firstOrNull() }.getOrNull() ?: return -1
        val earthKm = 6371.0
        val dLat = Math.toRadians(destination.latitude - origin.latitude)
        val dLon = Math.toRadians(destination.longitude - origin.longitude)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(Math.toRadians(origin.latitude)) * cos(Math.toRadians(destination.latitude)) * sin(dLon / 2) * sin(dLon / 2)
        val straightKm = earthKm * 2 * asin(sqrt(a.coerceIn(0.0, 1.0)))
        // GPS/Geocoder-Schätzung: Straßennetzfaktor plus typische Stadt-/Landgeschwindigkeit.
        val roadKm = straightKm * if (straightKm < 8.0) 1.28 else 1.18
        val averageKmh = when {
            roadKm < 3.0 -> 28.0
            roadKm < 10.0 -> 38.0
            roadKm < 30.0 -> 52.0
            else -> 68.0
        }
        return ((roadKm / averageKmh) * 60.0 + 1.5).roundToInt().coerceIn(2, 240)
    }

    inner class AndroidBridge(private val context: Context) {
        @android.webkit.JavascriptInterface
        fun scheduleReminder(id: Int, epochMillis: Long, title: String, message: String) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("title", title); putExtra("message", message); putExtra("id", id)
            }
            val pendingIntent = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
            } catch (_: SecurityException) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                Toast.makeText(context, "Exakte Alarme bitte in Android erlauben.", Toast.LENGTH_LONG).show()
                if (android.os.Build.VERSION.SDK_INT >= 31) runCatching {
                    context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun cancelReminder(id: Int) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingIntent = PendingIntent.getBroadcast(context, id, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarmManager.cancel(pendingIntent)
        }

        @android.webkit.JavascriptInterface
        fun speak(message: String, volumePercent: Int, gender: String) = runOnUiThread {
            speakNative(message, volumePercent, gender, false)
        }

        @android.webkit.JavascriptInterface
        fun speakThenListen(message: String, volumePercent: Int, gender: String) = runOnUiThread {
            speakNative(message, volumePercent, gender, true)
        }

        @android.webkit.JavascriptInterface
        fun startListening() = runOnUiThread { startNativeListening() }

        @android.webkit.JavascriptInterface
        fun estimateDriveMinutes(address: String): Int = estimateDriveMinutesForAddress(address)

        @android.webkit.JavascriptInterface
        fun requestLocationPermission() = runOnUiThread {
            val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }

        @android.webkit.JavascriptInterface
        fun isNativeApp(): Boolean = true
    }
}
